package mazo_cartas_pocima;

public class Pocima extends Cartas {

	@Override
	public boolean verificar() {
		// TODO Auto-generated method stub
		return false;
	}

}
