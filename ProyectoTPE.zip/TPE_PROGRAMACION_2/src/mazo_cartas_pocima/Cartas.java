package mazo_cartas_pocima;

public abstract class Cartas {
	
	public abstract boolean verificar();
}
